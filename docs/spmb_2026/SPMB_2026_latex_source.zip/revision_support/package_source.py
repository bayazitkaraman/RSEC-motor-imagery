"""Package current LaTeX sources, provenance, and the named historical baseline."""

from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
names = ["SPMBRiemannSteBK.tex", "SPMBRiemannSteBK_changes.tex", "SPMBRiemannSteBK.bbl",
         "references.bib", "IEEEtranSPMB.cls", "IEEEbibSPMB.bst", "pipeline.png",
         "fig3_real_minus_surrogate_delta.png",
         "README.txt", "CHANGE_SUMMARY.txt", "CHANGES.diff", "VALIDATION.json"]
files = [root / name for name in names]
support = root / "revision_support"
files += list(support.glob("table_*.tex"))
files += [support / name for name in ("participant_spatial_results.pdf", "participant_spatial_results.png",
                                     "comparison_uncertainty.pdf", "comparison_uncertainty.png",
                                     "red_preamble.tex", "references_changes.bbl", "expanded_clean.tex",
                                     "build_assets.py", "build_changes.py", "validate_revision.py",
                                     "package_source.py", "DATA_MANIFEST.json", "CHANGE_MANIFEST.json",
                                     "AUTHOR_FIGURE1.json", "SUPPLEMENT_INDEX.txt")]
files += list((support / "data").glob("*.csv"))
files += [p for p in (root / "approved_baseline").iterdir() if p.is_file()]
assert all(p.is_file() for p in files)
assert len(files) == len(set(files))
archive = root / "SPMB_2026_latex_source.zip"
with ZipFile(archive, "w", ZIP_DEFLATED) as output:
    for path in sorted(files):
        output.write(path, path.relative_to(root).as_posix())
with ZipFile(archive) as output:
    assert output.testzip() is None
print(f"Packaged and CRC-checked {len(files)} files: {archive.name}")
