"""Generate red additions/replacements with the installed standalone latexdiff."""

from pathlib import Path
import argparse
import difflib
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent
SUPPORT = ROOT / "revision_support"
BASE = ROOT / "approved_baseline"

parser = argparse.ArgumentParser()
parser.add_argument("--perl", default=r"C:\Program Files\Git\usr\bin\perl.exe")
parser.add_argument("--latexdiff", default=str(Path.home() / "AppData/Local/Programs/MiKTeX/scripts/latexdiff/latexdiff-so"))
args = parser.parse_args()

expanded = (ROOT / "SPMBRiemannSteBK.tex").read_text(encoding="utf-8-sig")
for name in ("table_primary", "table_comparisons", "table_sensitivity"):
    command = "\\input{revision_support/" + name + ".tex}"
    assert expanded.count(command) == 1
    expanded = expanded.replace(command, (SUPPORT / (name + ".tex")).read_text())
expanded_path = SUPPORT / "expanded_clean.tex"
expanded_path.write_text(expanded, encoding="utf-8")

result = subprocess.run([
    args.perl, args.latexdiff, "--no-del", "--graphics-markup=none",
    "--math-markup=whole", "--preamble=revision_support/red_preamble.tex",
    "approved_baseline/SPMBRiemannSteBK.tex", str(expanded_path),
], cwd=ROOT, capture_output=True, text=True, encoding="utf-8", check=True)
(SUPPORT / "latexdiff_diagnostics.txt").write_text(result.stderr, encoding="utf-8")

# Added bibliography entries are marked too; their numbering matches the clean PDF.
old_bib = (BASE / "references.bib").read_text(encoding="utf-8-sig")
old_keys = set(re.findall(r"@\w+\s*\{\s*([^,]+),", old_bib))
bbl = (ROOT / "SPMBRiemannSteBK.bbl").read_text(encoding="utf-8")
new_keys = []
copyedited_keys = {
    "pfurtscheller1999erd", "neuper2005imagery", "nolte2004imaginary", "stam2007pli",
    "nunez1997coherency", "goldberger2000physionet", "eegmmidb", "schalk2004bci2000",
}

def mark_entry(match):
    key, entry = match.group(1), match.group(0)
    if key not in old_keys:
        new_keys.append(key)
    if key not in old_keys or key in copyedited_keys:
        return "\\begingroup\\color{revisionred}\n" + entry.rstrip() + "\n\\par\\endgroup\n\n"
    return entry

marked_bbl = re.sub(r"\\bibitem\{([^}]+)\}[\s\S]*?(?=\\bibitem\{|\\end\{thebibliography\})", mark_entry, bbl)
(SUPPORT / "references_changes.bbl").write_text(marked_bbl, encoding="utf-8")
red_source = result.stdout.replace(r"\bibliography{references}", r"\input{revision_support/references_changes.bbl}")
# Suppressed deletions can leave spaces before punctuation at markup boundaries.
red_source = re.sub(r"\s+(?=\\DIFaddbegin(?:FL)?\s+\\DIFadd(?:FL)?\{[.,;:)])", "", red_source)
red_source = re.sub(r"(\\DIFaddend(?:FL)?)[ \t]+(?=[.,;:)])", r"\1", red_source)
head, boundary, body = red_source.partition(r"\begin{document}")
body = re.sub(r"(?<=[\w}])[ \t]+(?=[,.;:])", "", body)
red_source = head + boundary + body
figure_record = json.loads((SUPPORT / "AUTHOR_FIGURE1.json").read_text())
assert hashlib.sha256((ROOT / "pipeline.png").read_bytes()).hexdigest() == figure_record["sha256"]
# Color the unchanged caption to identify the author's updated figure pixels.
red_source, figure_caption_count = re.subn(
    r"(\\caption\{)(Overview of the RSEC feature-extraction pipeline\.[^\n]*)(\}\s*\\label\{fig:rsec_pipeline\})",
    lambda m: m[1] + r"\DIFaddFL{" + m[2] + "}" + m[3], red_source)
if figure_caption_count == 0:
    # Moving a float can cause latexdiff to mark its full caption already.
    assert red_source.count(r"\caption{\DIFaddFL{Overview of the RSEC feature-extraction pipeline.") == 1
else:
    assert figure_caption_count == 1
(ROOT / "SPMBRiemannSteBK_changes.tex").write_text(red_source, encoding="utf-8")

diff = []
for filename in ("SPMBRiemannSteBK.tex", "references.bib"):
    diff.extend(difflib.unified_diff(
        (BASE / filename).read_text(encoding="utf-8-sig").splitlines(keepends=True),
        (ROOT / filename).read_text(encoding="utf-8-sig").splitlines(keepends=True),
        fromfile="approved_baseline/" + filename, tofile=filename))
for filename in ("table_primary.tex", "table_comparisons.tex", "table_sensitivity.tex"):
    diff.extend(difflib.unified_diff([], (SUPPORT / filename).read_text().splitlines(keepends=True),
                                     fromfile="/dev/null", tofile="revision_support/" + filename))
(ROOT / "CHANGES.diff").write_text("".join(diff), encoding="utf-8")
(SUPPORT / "CHANGE_MANIFEST.json").write_text(json.dumps({
    "baseline": "approved_baseline/SPMBRiemannSteBK.tex",
    "baseline_sha256": hashlib.sha256((BASE / "SPMBRiemannSteBK.tex").read_bytes()).hexdigest(),
    "comparison": "Word-level additions/replacements red; deletions omitted from PDF and recorded in CHANGES.diff",
    "new_references": new_keys,
    "capitalization_corrected_references": sorted(copyedited_keys),
    "new_figures": ["revision_support/participant_spatial_results.pdf",
                    "revision_support/comparison_uncertainty.pdf"],
    "retained_figures": ["fig3_real_minus_surrogate_delta.png (same pixels)"],
    "author_updated_figure": figure_record,
    "figure_1_markup": "Caption red to identify updated figure; image colors preserved",
    "page_target": None,
}, indent=2) + "\n", encoding="utf-8")
print("Generated red-text LaTeX and complete source diff. New references:", new_keys)
if result.stderr.strip():
    print(result.stderr[:6000])
