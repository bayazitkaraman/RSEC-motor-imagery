"""Audit numerical claims, preservation, compilation and clean/red PDF text."""

from pathlib import Path
import csv
import hashlib
import json
import re

import pdfplumber
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent.parent
SUPPORT = ROOT / "revision_support"


def rows(name):
    with (SUPPORT / "data" / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = (ROOT / "SPMBRiemannSteBK.tex").read_text()
expanded = (SUPPORT / "expanded_clean.tex").read_text()
assert not re.search(r"\b(we|our|ours|my|mine)\b", expanded, re.I)
assert not re.search(r"\bI\s+(?:am|have|was|used|use|present|propose|evaluate|found|show|report)\b", expanded)
assert "linear-q" not in source.lower() and "ablation" not in source.lower()
assert not re.search(r"four[ -]of[ -]six|4\s*/\s*6", source, re.I)
assert "do not isolate the contributions" in source
assert "Rest and imagery epochs were independently phase-randomized" in source
assert "unfiltered" not in source.lower()
assert r"Here, $\log$ denotes the natural logarithm." in source
assert "Electrooculography (EOG)-informed" in source
assert "Global density contrasts were sensitive to amplitude-based epoch rejection." in source
abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", source, re.S).group(1)
assert len(abstract.split()) <= 250
old = json.loads((ROOT / "approved_baseline/VALIDATION.json").read_text())
assert sha(ROOT / "approved_baseline/SPMBRiemannSteBK.tex") == old["revised_sha256"]
assert sha(ROOT / "approved_baseline/SPMBRiemannSteBK.pdf") == old["pdf_sha256"]
preserved = {}
for name in ("IEEEtranSPMB.cls", "IEEEbibSPMB.bst", "fig3_real_minus_surrogate_delta.png"):
    preserved[name] = sha(ROOT / name)
    assert preserved[name] == old["unchanged_file_sha256"][name]
figure_record = json.loads((SUPPORT / "AUTHOR_FIGURE1.json").read_text())
assert sha(ROOT / "pipeline.png") == figure_record["sha256"]
manifest = json.loads((SUPPORT / "DATA_MANIFEST.json").read_text())
for name, record in manifest.items():
    assert sha(SUPPORT / "data" / name) == record["sha256"]
    original = ROOT.parent / "spmb_revision_analysis" / record["source"]
    if original.exists():
        assert sha(original) == record["sha256"]

comparison = rows("statistics_54.csv")
assert len(comparison) == 54 and all(int(r["n"]) == 106 for r in comparison)
idx = {(r["band"], r["contrast"], r["metric"]): r for r in comparison}
metrics = ["rsec_d3", "power_uv2", "coh", "plv", "pli", "wpli"]
order = [(b, c) for b in ("broadband", "mu", "beta")
         for c in ("imagery-rest", "execution-rest", "imagery-execution")]
table = [s for s in (SUPPORT / "table_comparisons.tex").read_text().splitlines()
         if s.startswith(("Broadband &", "Mu &", "Beta &"))]
assert len(table) == 9
for line, (band, contrast) in zip(table, order):
    cells = line.split(" & ")[2:]
    assert len(cells) == 6
    for cell, metric in zip(cells, metrics):
        value = float(re.search(r"[+-]?\d+\.\d+", cell).group())
        record = idx[band, contrast, metric]
        assert abs(value - float(record["dz"])) <= .0005
        assert ("^{*}" in cell) == (float(record["p_holm_54"]) < .05)
wins = [[b, c] for b, c in order if c != "execution-rest" and
        all(abs(float(idx[b, c, "rsec_d3"]["dz"])) > abs(float(idx[b, c, m]["dz"])) for m in metrics[1:])]
assert len(wins) == 4
paired = rows("paired_effect_comparisons_45.csv")
imagery = [r for r in paired if r["contrast"] != "execution-rest"]
assert len(paired) == 45 and len(imagery) == 30
assert all(float(r["ci_low"]) < 0 < float(r["ci_high"]) for r in imagery)
for name in ("participant_spatial_results", "comparison_uncertainty"):
    assert (SUPPORT / (name + ".pdf")).stat().st_size > 1000
    assert (SUPPORT / (name + ".png")).stat().st_size > 1000
related = re.search(r"\\section\{Related Work\}(.*?)(?=\\section\{)", source, re.S).group(1)
assert all(term in related.lower() for term in ("neuper2005", "ahn", "stereographic"))
primary = rows("primary_statistics.csv")
assert [int(r["n_decrease"]) for r in primary[:3]] == [66, 49, 84]
assert [float(r["p_holm"]) < .05 for r in primary] == [True, False, True, True]
assert len(rows("sensitivity_statistics.csv")) == 21
contrast_names = {"imagery-rest", "execution-rest", "imagery-execution"}
for filename, group in (("sensitivity_statistics.csv", "setting"),
                        ("paired_effect_comparisons_45.csv", "band"),
                        ("amplitude_aggregation_statistics.csv", "setting")):
    records = rows(filename)
    for setting in {r[group] for r in records}:
        assert {r["contrast"] for r in records if r[group] == setting} == contrast_names
artifact_rsec = [r for r in rows("amplitude_aggregation_statistics.csv") if r["metric"] == "rsec"]
assert len(artifact_rsec) == 27 and len({r["setting"] for r in artifact_rsec}) == 9
assert len([r for r in rows("csd_statistics.csv") if r["metric"] == "rsec"]) == 3
assert "correction family also includes execution--rest tests" in (SUPPORT / "table_sensitivity.tex").read_text()
assert sum(float(r["p_holm"]) < .05 for r in rows("imagery_channel_statistics.csv")) == 23
assert [int(r["n_decrease"]) for r in rows("imagery_roi_statistics.csv")] == [78, 54, 76]
amplitude = {(r["setting"], r["contrast"]): r for r in rows("amplitude_aggregation_statistics.csv") if r["metric"] == "rsec"}
for setting, n in (("fp-ptp-150", 15), ("fp-ptp-250", 34)):
    record = amplitude[setting, "imagery-rest"]
    assert int(record["n"]) == n
    assert float(record["mean_delta"]) > 0 > float(record["matched_original_mean_delta"])
assert abs(float(amplitude["fp-ptp-150", "imagery-execution"]["dz"]) - .054) < .0005


def fonts_in(resources, seen=None):
    seen = set() if seen is None else seen
    resources = resources.get_object()
    if "/Font" in resources:
        for font in resources["/Font"].get_object().values():
            yield font.get_object()
    if "/XObject" in resources:
        for reference in resources["/XObject"].get_object().values():
            key = str(reference)
            if key not in seen:
                seen.add(key)
                obj = reference.get_object()
                if "/Resources" in obj:
                    yield from fonts_in(obj["/Resources"], seen)


def is_embedded(font):
    if "/DescendantFonts" in font:
        return all(is_embedded(f.get_object()) for f in font["/DescendantFonts"])
    descriptor = font.get("/FontDescriptor")
    return descriptor is not None and any(k in descriptor.get_object() for k in ("/FontFile", "/FontFile2", "/FontFile3"))


def content_text(reader):
    parts = []
    for page in reader.pages:
        text = re.sub(r"^B\. Karaman:[^\n]*\n", "", page.extract_text())
        parts.append(text.split("979-8-3195-")[0])
    return re.sub(r"[\s-]", "", "".join(parts))


pdfs, readers = {}, []
for name in ("SPMBRiemannSteBK", "SPMBRiemannSteBK_changes"):
    log = (ROOT / (name + ".log")).read_text(errors="replace")
    assert not re.search(r"Overfull|undefined|^!|Fatal error|Rerun to get", log, re.M)
    reader = PdfReader(ROOT / (name + ".pdf"))
    bibliography_text = "\n".join(p.extract_text() for p in reader.pages).split("REFERENCES")[-1]
    assert all(term in bibliography_text for term in ("EEG/MEG", "BCI2000", "PhysioBank", "PhysioToolkit", "PhysioNet"))
    readers.append(reader)
    assert len(reader.pages) > 0
    fonts = {}
    for page in reader.pages:
        assert tuple(float(v) for v in page.mediabox) == (0, 0, 612, 792)
        for font in fonts_in(page["/Resources"]):
            assert is_embedded(font), font
            assert font["/Subtype"] != "/Type3"
            fonts[str(font.get("/BaseFont", "unknown"))] = str(font["/Subtype"])
    reds = []
    with pdfplumber.open(ROOT / (name + ".pdf")) as pdf:
        for page in pdf.pages:
            count = 0
            for char in page.chars:
                assert 69 <= char["x0"] <= char["x1"] <= 543.5, (name, page.page_number, char)
                color = char.get("non_stroking_color")
                if isinstance(color, (tuple, list)) and len(color) == 3:
                    count += int(color[0] > .5 and color[1] < .2 and color[2] < .2)
            reds.append(count)
    assert sum(reds) > 100 if name.endswith("changes") else sum(reds) == 0
    pdfs[name + ".pdf"] = {"sha256": sha(ROOT / (name + ".pdf")), "pages": len(reader.pages),
                           "page_size_points": [612, 792], "embedded_fonts": fonts,
                           "red_characters_per_page": reds, "overfull_boxes": 0,
                           "unresolved_citations_or_references": 0}
assert content_text(readers[0]) == content_text(readers[1])
status = {
    "status": "compiled_scientific_revision_validated",
    "manuscript_status": "Accepted with mandatory revision; author and conference approval pending",
    "source_sha256": sha(ROOT / "SPMBRiemannSteBK.tex"),
    "no_authorial_first_person": True,
    "abstract_whitespace_token_count": len(abstract.split()),
    "related_work_whitespace_token_count": len(related.split()),
    "page_target": None,
    "approved_source_and_pdf_preserved": True,
    "unchanged_assets": preserved,
    "author_updated_figure_1": figure_record,
    "ranking_slogan_removed": True,
    "precision_copyedits": ["Amplitude rejection terminology", "Global density versus regional participation", "Natural logarithm specified", "EOG expanded", "Reference capitalization protected"],
    "supporting_results_coverage": {"paired_comparisons": 45, "sensitivity_tests": 21, "rsec_artifact_settings": 9, "rsec_artifact_contrasts": 27, "rsec_csd_contrasts": 3},
    "data_files_verified": len(manifest),
    "comparison_entries_checked": 54,
    "rsec_largest_imagery_point_estimates": wins,
    "imagery_superiority_intervals_all_include_zero": True,
    "artifact_reversals_and_small_cohorts_retained": True,
    "red_and_clean_pdf_text_identical_ignoring_layout_hyphens": True,
    "pdfs": pdfs,
    "visual_qa": "Both complete PDFs rendered and inspected; no overlap or clipping",
    "supporting_archive_repository_path": "https://github.com/bayazitkaraman/RSEC-motor-imagery/tree/main/docs/spmb_2026",
    "outstanding": ["Author scientific approval", "Fresh similarity check", "Confirm nine-page length with organizers", "Response email and conference approval"],
    "not_performed": ["New EEG experiments", "New similarity score", "Email/submission"],
}
(ROOT / "VALIDATION.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
print(json.dumps({k: v for k, v in status.items() if k not in ("pdfs", "unchanged_assets")}, indent=2))
