RSEC SPMB 2026: original-based formatting and limited-language draft
October 2, 2026

STATUS
SPMBRiemannSteBK.pdf successfully compiled with the existing local MiKTeX
installation (pdfLaTeX and BibTeX). Six Letter pages were rendered and inspected.
Both tables fit without overfull-box warnings; citations and page references
resolve. This is still NOT the completed mandatory reviewer revision and is NOT
ready for submission. See the remaining content/formatting checks below.

The earlier error was specific to the built-in compiler, which failed to
initialize with "Unable to find standard directories for platform". It was
not a LaTeX syntax error. No compiler or package installation was needed.
Local compiler directory:
C:\Users\Bayazit Karaman\AppData\Local\Programs\MiKTeX\miktex\bin\x64
Compilation used --disable-installer and --no-shell-escape. Build logs and
auxiliary files are in .build; the delivered PDF is beside the main .tex file.

MAIN FILE
SPMBRiemannSteBK.tex
All required manuscript figures, references.bib, the official IEEEtranSPMB.cls,
and official IEEEbibSPMB.bst are included. Use the main file in an Overleaf
project with pdfLaTeX and BibTeX. This multi-file project was compiled locally.

STARTING POINT
D:\Projects\RSEC-motor-imagery\paper\overleaf_submitted_2026-08-29
The submitted source and PDF in that folder remain untouched. The older,
more extensively rewritten Word revisions were NOT used as the starting text.

SCOPE
Exactly four prose sentences were rephrased, listed in SENTENCE_CHANGES.txt.
All other manuscript wording, results, equations, citations, table contents and
figure captions were preserved. No first-person authorial wording was introduced.
Figure 1 remains the original pipeline.png in its original figure* block,
at 0.95 times the text width. No image was redrawn or altered.

FORMAT-ONLY CHANGES
- Use the official 2026 IEEEtranSPMB class and IEEEbibSPMB bibliography style.
- Use the template's title/author panel, keywords and first-page style.
- Add a running header for the sole author, Bayazit Karaman.
- Remove cite because the official class already loads natbib.
- Leave both downloaded class/style files unchanged.
- Restyle both tables after direct inspection of the Word template: gray bold
  header rows, thin gray borders around all cells, 9-point body text, right-aligned
  numbers and wrapped row labels. Remove the original booktabs styling. Table
  contents and captions are unchanged. The final rendered tables were inspected
  on page 4. Table 1's delta column was widened to eliminate three small overflows.
- Apply the official example's 8-point reference font and bibliography spacing.

TEMPLATE EVIDENCE
Official 2026 guidelines offer both Word and LaTeX templates:
https://isip.piconepress.com/conferences/ieee_spmb/2026/html/guidelines.shtml
Template source directory:
https://isip.piconepress.com/conferences/ieee_spmb/2026/forms/templates/
The downloaded Word template matches the earlier email-linked Word template
byte-for-byte (SHA256 C686130CD9B584C1CF7DC829C360940E1331B6C25032F2EDE181F7E398440736).
Both official sample PDFs use Letter paper and two-column body text. They
are not pixel-identical: the Word sample embeds Times New Roman; the LaTeX
sample embeds a Times-compatible Nimbus Roman font. Individual spacing and
line breaks differ. Template availability is not an individual organizer
approval of this particular manuscript's formatting.

FULL-WIDTH FIGURE PRECEDENT
Figure 2 on page 3 of this official 2025 SPMB paper spans both columns:
https://isip.piconepress.com/conferences/ieee_spmb/2025/papers/10_spmb_l03_05.pdf
The precedent supports retaining Figure 1 across both columns; it does not
replace inspection of the compiled manuscript's margins and readability.

REMAINING WORK
1. Complete the final formatting pass before submission. The original keywords
   occupy four lines; the official example asks for at most two. The final
   bibliography page also has an unbalanced column. Both are recorded rather
   than silently changing keyword wording or making this a full layout revision.
2. Integrate the verified reviewer-related scientific revisions separately.
   This narrow draft intentionally retains the submitted results and wording.
   In particular, the original "all available task epochs" statement still
   needs reconciliation with the audited 50-epoch cap. Updated conventional
   baseline comparisons and frontal-effect checks are not incorporated here.
3. Update the reviewer response, run a fresh similarity check on the actual
   final PDF, and obtain author approval before submission. The old report's
   21% score is not a measured score for this draft.

Nothing was emailed, submitted, committed, or pushed to GitHub.
