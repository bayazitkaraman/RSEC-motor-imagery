RSEC SPMB 2026: integrated scientific manuscript
October 2, 2026

CURRENT FILES
SPMBRiemannSteBK.tex / SPMBRiemannSteBK.pdf: clean expanded manuscript.
SPMBRiemannSteBK_changes.tex / SPMBRiemannSteBK_changes.pdf: red-text copy.
SPMB_2026_latex_source.zip: portable source package for both versions.
CHANGE_SUMMARY.txt: scientific changes and reviewer-coverage map.
CHANGES.diff: complete source-level additions and deletions.
VALIDATION.json: numerical, preservation, compilation and PDF checks.
revision_support/SUPPLEMENT_INDEX.txt: contents and interpretation of supporting results.

LATEST PRECISION PASS
Three targeted manuscript clarifications: amplitude rejection is distinguished
from frequency filtering; global density sensitivity is distinguished from
regional participation findings; log is explicitly natural. EOG is expanded at
first use, and EEG/MEG/BCI2000/PhysioBank/PhysioToolkit/PhysioNet capitalization is
protected in the bibliography. No result, model equation, figure pixel or table
value was changed. The preceding draft is in previous_before_precision_edit_2026-10-02.
The redline baseline remains approved_baseline, not this preceding snapshot.

This focused editorial revision supersedes the preceding expanded and page-limited drafts in this
folder. There is no page-count target: relevance, clarity, and evidential support
determine the content. It is written as an original paper, without reviewer-response
wording or authorial "I"/"we". No new EEG experiments were run in this manuscript
preparation step: previously validated outputs were integrated and checked.
Acceptance remains subject to the mandatory-revision process and conference approval.

RED-TEXT CONVENTION
Red marks added or replaced words relative to the last approved, formatted draft
in approved_baseline/SPMBRiemannSteBK.tex, not an intermediate Word draft. The four
earlier similarity-related edits are already part of that baseline. Their history
is in approved_baseline/SENTENCE_CHANGES.txt. The root SENTENCE_CHANGES.txt is also
historical and does not describe the current scientific revision.

The red PDF contains the same current manuscript as the clean PDF. Deletions are
omitted, not struck through; CHANGES.diff records them. Changed equations, table
entries, figure captions, and new references are marked. Figure 1's caption is red
to identify the author's updated image; the image itself is not recolored. Plots retain scientific
colors. Minor line-wrap differences result from markup.

PRESERVATION
Original submitted source:
D:\Projects\RSEC-motor-imagery\paper\overleaf_submitted_2026-08-29
That source, raw EEG, and saved analysis outputs remain untouched.
approved_baseline contains the approved pre-scientific-revision source and PDF.
previous_page_limited_2026-10-02 preserves the preceding six-page scientific
revision, including its clean/red sources and PDFs. This local archive is not
the redline baseline and is not duplicated inside the new source ZIP.
previous_expanded_before_edit_2026-10-02 preserves the nine-page draft before this
focused editing pass. Neither intermediate snapshot is the redline baseline.
The official IEEEtranSPMB.cls and IEEEbibSPMB.bst are byte-for-byte unchanged.
pipeline.png is the author's updated image, spanning both columns at 0.95 text width.
Its epsilon_n denominator and epsilon_E logarithm stabilizer were checked against
the equations before compilation. AUTHOR_FIGURE1.json records its SHA256 hash.
fig3_real_minus_surrogate_delta.png is restored without pixel changes.
Unused old result images and .build are historical, not current compilation inputs.
Current PDFs and logs are beside their main .tex files.

FORMAT AND BUILD
Letter pages; official IEEE SPMB 2026 class/style; 10-point body, two-line
keywords, 8-point references, balanced final columns, gray bold table headers and
thin gray grids. Existing MiKTeX was used with installation and shell escape
disabled. All fonts are embedded. Known caption/titlesec warnings originate from
the official class; there are no undefined citations/references or overfull boxes.
The actual page count is recorded in VALIDATION.json, not imposed on the text.
This is the full scientific draft; final submission length awaits author decision.

CONTENT AND FIGURES
Related Work restores the motor-imagery, connectivity, graph/hub, geometry, and
earlier AHN context and explains the rationale for native conventional benchmarks.
Methods describe model construction and reproducible comparison design. The
whole-pipeline comparison limitation is acknowledged once; no ablation was added.
The four-of-six ranking slogan was removed without removing any comparison data.
Surrogates are explicitly generated for both rest and imagery. Table 3 clarifies
its 21-test family, including execution-rest results present in the supporting CSV.
Regional probabilities are explicitly Holm-adjusted within a three-test family.
Repeated caveats and response-like wording were shortened; the scientific
limitations, unfavorable results, and substantive Related Work were retained.
The MNE reference retains correct capitalization. Results floats precede Discussion.
Discussion separates operational findings, plausible physiological explanations,
artifact sensitivity, comparative uncertainty, and prospective BCI validation.
Four figures support distinct aspects of the paper:
1. Author-updated two-column pipeline, checked before compilation.
2. Signed participant-level global and regional differences.
3. Original surrogate-control distribution, with raw/corrected p values clarified.
4. New six-panel effect-size comparison with multiplicity-adjusted uncertainty.
The new figure visualizes existing validated results; it is not a new experiment.

For Overleaf, extract the source ZIP into one project and select pdfLaTeX.
Clean main: SPMBRiemannSteBK.tex. Red main: SPMBRiemannSteBK_changes.tex.
No Python or latexdiff installation is needed to compile the supplied sources.
The red source uses the included revision_support/references_changes.bbl.
Local clean build: pdflatex, bibtex, pdflatex, pdflatex on SPMBRiemannSteBK.
Local red build: pdflatex twice on SPMBRiemannSteBK_changes.
MiKTeX directory on this machine:
C:\Users\Bayazit Karaman\AppData\Local\Programs\MiKTeX\miktex\bin\x64
Use --disable-installer --no-shell-escape with local pdflatex.

REGENERATION
revision_support/build_assets.py generates three tables and two figures from CSVs using NumPy
and Matplotlib. Packaged CSVs are used when the original analysis paths are absent.
revision_support/build_changes.py uses standalone latexdiff and Perl; default
paths match this PC and can be overridden. Run after compiling the clean
bibliography, then recompile the red copy. revision_support/validate_revision.py
uses pypdf/pdfplumber for numerical, source-preservation, and PDF checks.

PROVENANCE
Primary/sensitivity/spatial: spmb_revision_analysis/results.
Native comparisons: review_completion_2026-10-02/results/statistics_54.csv.
Paired effects: paired_effect_comparisons_45.csv in that same directory.
Cohort/rate checks: pipeline_audit_2026-10-02/results.
Artifact checks: followup_2026-10-01/results.
Full paths and SHA256 hashes: revision_support/DATA_MANIFEST.json.
Artifact CSVs retain original correction-family columns for provenance. Only
descriptive RSEC artifact results are used in the manuscript; no family was
silently reduced or reinterpreted to obtain significance.

BEFORE SUBMISSION
The official 2026 guidelines, checked October 2, 2026, state four to six pages
as preferred; no explicit hard maximum for full papers is stated on that page:
https://isip.piconepress.com/conferences/ieee_spmb/2026/html/guidelines.shtml
That wording does not establish permission for a nine-page final paper. Confirm
the length with the organizers; no content was cut solely for space.
Author scientific and length decisions, a fresh similarity check on the final PDF,
the detailed response email, and conference approval remain necessary. Supply the
source archive with the manuscript when requested. The repository location named
in Data and Code Availability is docs/spmb_2026/ in RSEC-motor-imagery. This
archive regenerates tables and figures from saved results; it does not contain
the full raw-EEG analysis environment. No current
similarity percentage is claimed. Statistical superiority, artifact-independent
physiology, and individual BCI accuracy are not established and are not claimed.
Nothing was emailed or submitted to the conference. The author separately requested
a GitHub update; manuscript and supporting files use the existing repository
structure. Private future-paper projects are outside that public update.
